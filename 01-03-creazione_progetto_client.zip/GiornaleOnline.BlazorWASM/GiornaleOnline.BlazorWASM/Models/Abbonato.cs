﻿namespace GiornaleOnline.BlazorWASM.Models
{
    public class Abbonato
    {
        public string Nome { get; set; } = string.Empty;
        public string Cognome { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public Indirizzo Indirizzo { get; set; } = new Indirizzo();
    }

    public class Indirizzo
    {
        public string Via { get; set; } = string.Empty;
        public string Civico { get; set; } = string.Empty;
        public string Citta { get; set; } = string.Empty;
    }

    public static class Abbonati
    {
        public static List<Abbonato> Lista
        {
            get => new List<Abbonato>
            {
                new Abbonato { Nome = "Mario", Cognome = "Rossi", Email = "mario@gmail.com", Indirizzo = new Indirizzo { Via = "Via Leopardi", Civico = "2", Citta = "Roma" } },
                new Abbonato { Nome = "Giovanna", Cognome = "Verdi", Email = "giovanna@gmail.com", Indirizzo = new Indirizzo { Via = "Via della Resistenza", Civico = "24", Citta = "Ancona" } },
                new Abbonato { Nome = "Elisa", Cognome = "Bianchi", Email = "elisa@gmail.com", Indirizzo = new Indirizzo { Via = "Viale dei Caduti", Civico = "1456", Citta = "Milano" } }
            };
        }
    }
}
﻿namespace GiornaleOnline.BlazorWASM.Models
{
    public class ArticoloModel
    {
        public int Id { get; set; }

        public virtual UtenteModel? Autore { get; set; }

        public virtual CategoriaModel? Categoria { get; set; }

        public string? Titolo { get; set; }

        public string? Testo { get; set; }

        public DateTime DataCreazione { get; set; }
    }
}

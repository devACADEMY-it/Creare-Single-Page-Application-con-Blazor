﻿namespace GiornaleOnline.BlazorWASM.Models
{
    public class UtenteModel
    {
        public int Id { get; set; }
        public string? Nome { get; set; }

        public string? Username { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace GiornaleOnline.BlazorWASM.Models
{    
    public class CategoriaDTO
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Il campo {0} è obbligatorio.")]
        public string? Nome { get; set; }
    }
}

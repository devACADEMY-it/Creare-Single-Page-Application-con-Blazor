﻿using Blazored.LocalStorage;
using GiornaleOnline.BlazorWASM.Models;
using Microsoft.AspNetCore.Components.Authorization;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http.Headers;
using System.Security.Claims;

namespace GiornaleOnline.BlazorWASM.Services
{    
    public class CustomAuthenticationStateProvider : AuthenticationStateProvider
    {
        //public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        //{
        //    string token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJHT0pXVFNlcnZpY2VBY2Nlc3NUb2tlbiIsImp0aSI6Ijg4NTEyOTlmLTljNjktNDFlMS1iYThkLWYxYjQ4OTU3NzRhNiIsImlhdCI6IjExLzA5LzIwMjIgMTA6MjE6MTIiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1lIjoiR2lnaSBSb3NzaSIsIlVzZXJJZCI6IjIiLCJEaXNwbGF5TmFtZSI6IkdpZ2kgUm9zc2kiLCJVc2VybmFtZSI6ImdpZ2kiLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJ1c2VyIiwiZXhwIjoxNjYyOTI3NjcyLCJpc3MiOiJHT0F1dGhlbnRpY2F0aW9uU2VydmVyIiwiYXVkIjoiKiJ9.LN0UkSgnTwSxreDtqqaAq2WZoiJ7YHmK0Wr5pbZJv0A";

        //    // parseing del token
        //    JwtSecurityTokenHandler handler = new();
        //    var jwt = handler.ReadJwtToken(token);

        //    var identity = new ClaimsIdentity(jwt.Claims, "jwt");

        //    identity = new ClaimsIdentity();
        //    var user = new ClaimsPrincipal(identity);
        //    var state = new AuthenticationState(user);

        //    NotifyAuthenticationStateChanged(Task.FromResult(state));

        //    return state;
        //}

        private readonly HttpClient _http;
        private readonly ILocalStorageService _localStorage;        

        public CustomAuthenticationStateProvider(HttpClient http, ILocalStorageService localStorage)
        {
            _http = http;
            _localStorage = localStorage;            
        }

        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            var identity = new ClaimsIdentity();

            _http.DefaultRequestHeaders.Authorization = null;

            var utenteInfo = await _localStorage.GetItemAsync<UtenteInfo>("user");
            if (utenteInfo != null)
            {
                identity = new ClaimsIdentity(ParseJwtToken(utenteInfo.Token), "jwt");
                _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", utenteInfo.Token);
            }

            var user = new ClaimsPrincipal(identity);
            var state = new AuthenticationState(user);

            NotifyAuthenticationStateChanged(Task.FromResult(state));

            return state;
        }

        private IEnumerable<Claim> ParseJwtToken(string token)
        {
            JwtSecurityTokenHandler handler = new();
            var jwt = handler.ReadJwtToken(token);

            return jwt.Claims;
        }
    }
}

﻿namespace GiornaleOnline.BlazorWASM.Services
{
    public enum MessageType
    {
        Success,
        Error,
        Warning
    }

    public interface IMessageService
    {
        void SendMessage(string msg, MessageType type, int durataInSecondi);
        string CurrentMessage { get; set; }
        MessageType CurrentType { get; set; }

        event Action? OnMessageSent;

        Task StartTimerAsync(int durataInSecondi);
    }

    public class MessageService : IMessageService
    {
        public string CurrentMessage { get; set; } = string.Empty;
        public MessageType CurrentType { get; set; } = MessageType.Success;

        public event Action? OnMessageSent;

        private void NotifyStateChanged() => OnMessageSent?.Invoke();

        public void SendMessage(string msg, MessageType type, int durataInSecondi)
        {
            CurrentMessage = msg;
            CurrentType = type;

            NotifyStateChanged();

            _ = StartTimerAsync(durataInSecondi);

        }

        public async Task StartTimerAsync(int durataInSecondi)
        {
            await Task.Delay(1000 * durataInSecondi);
            CurrentMessage = string.Empty;

            NotifyStateChanged();
        }
    }
}

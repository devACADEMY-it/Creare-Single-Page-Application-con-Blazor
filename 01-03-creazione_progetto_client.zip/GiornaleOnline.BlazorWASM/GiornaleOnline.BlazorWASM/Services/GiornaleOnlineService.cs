﻿using Blazored.LocalStorage;
using GiornaleOnline.BlazorWASM.Models;
using Microsoft.AspNetCore.Components.Authorization;
using System.Net.Http.Json;
using System.Reflection;

namespace GiornaleOnline.BlazorWASM.Services
{
    public interface IGiornaleOnlineService
    {
        List<ArticoloModel> Articoli { get; set; }
        List<CategoriaModel> Categorie { get; set; }
        Task GetArticoliAsync();
        Task<ArticoloModel?> GetArticoloByIdAsync(int id);
        Task GetCategorieAsync();
        Task<CategoriaModel?> GetCategoriaByIdAsync(int id);
        Task GetArticoliByCategoriaIdAsync(int id);


        // ADMIN CATEGORIE
        Task<CategoriaModel?> AddCategoriaAsync(CategoriaDTO model);
        Task<CategoriaModel?> EditCategoriaAsync(int id, CategoriaDTO model);
        Task<bool> DeleteCategoriaAsync(int id);
        Task<CategoriaDTO?> GetCategoriaEditByIdAsync(int id);


        // ADMIN ARTICOLI
        List<ArticoloModel> MieiArticoli { get; set; }
        Task GetArticoliMieiAsync();
        Task<ArticoloModel?> AddArticoloAsync(ArticoloDTO model);
        Task<ArticoloModel?> EditArticoloAsync(int id, ArticoloDTO model);
        Task<bool> DeleteArticoloAsync(int id);
        Task<ArticoloDTO?> GetArticoloEditByIdAsync(int id);


        // Autenticazione
        Task<UtenteInfo?> LoginAsync(LoginDTO model);

        Task<UtenteInfo?> RegisterAsync(RegisterDTO model);

        // 07-ESERCITAZIONE REGISTRAZIONE
        // - Creare il metodo in IGiornaleOnlineService per la registrazione sul server API
        // - Creare la pagina con form di registrazione che utilizzi il metodo di cui sopra
    }

    public class GiornaleOnlineService : IGiornaleOnlineService
    {
        private readonly HttpClient _http;
        private readonly ILocalStorageService _localStorage;
        private readonly AuthenticationStateProvider _authState;
        private readonly IMessageService _msgService;

        public GiornaleOnlineService(HttpClient http, ILocalStorageService localStorage, AuthenticationStateProvider authState, IMessageService msgService)
        {
            _http = http;
            _localStorage = localStorage;
            _authState = authState;
            _msgService = msgService;
        }

        public List<ArticoloModel> Articoli { get; set; }
        public List<CategoriaModel> Categorie { get; set; }
        public List<ArticoloModel> MieiArticoli { get; set; }

        public async Task<ArticoloModel?> AddArticoloAsync(ArticoloDTO model)
        {
            try
            {
                var resp = await _http.PostAsJsonAsync("articoli", model);

                if (resp.IsSuccessStatusCode)
                {
                    var retItem = await resp.Content.ReadFromJsonAsync<ArticoloModel>();

                    if (retItem == null)
                    {
                        return null;
                    }

                    _msgService.SendMessage("Articolo creato con successo", MessageType.Success, 5);
                    return retItem;
                }
                else
                {
                    await HandleError(resp);
                    return null;
                }
            }
            catch (Exception ex)
            {
                _msgService.SendMessage(ex.Message, MessageType.Error, 5);
                return null;
            }
        }

        public async Task<CategoriaModel?> AddCategoriaAsync(CategoriaDTO model)
        {
            try
            {
                var resp = await _http.PostAsJsonAsync("categorie", model);

                if (resp.IsSuccessStatusCode)
                {
                    var retItem = await resp.Content.ReadFromJsonAsync<CategoriaModel>();

                    if (retItem == null)
                    {
                        return null;
                    }

                    _msgService.SendMessage("Categoria creata con successo", MessageType.Success, 5);
                    return retItem;
                }
                else
                {
                    await HandleError(resp);
                    return null;
                }
            }
            catch (Exception ex)
            {
                _msgService.SendMessage(ex.Message, MessageType.Error, 5);
                return null;
            }
        }

        public async Task<bool> DeleteArticoloAsync(int id)
        {
            try
            {
                var resp = await _http.DeleteAsync("articoli/" + id);

                if (resp.IsSuccessStatusCode)
                {
                    _msgService.SendMessage("Articolo eliminato con successo", MessageType.Success, 5);
                    return true;
                }
                else
                {
                    await HandleError(resp);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _msgService.SendMessage(ex.Message, MessageType.Error, 5);
                return false;
            }
        }

        public async Task<bool> DeleteCategoriaAsync(int id)
        {
            try
            {
                var resp = await _http.DeleteAsync("categorie/" + id);

                if (resp.IsSuccessStatusCode)
                {
                    _msgService.SendMessage("Categoria eliminata con successo", MessageType.Success, 5);
                    return true;
                }
                else
                {
                    await HandleError(resp);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _msgService.SendMessage(ex.Message, MessageType.Error, 5);
                return false;
            }
        }

        public async Task<ArticoloModel?> EditArticoloAsync(int id, ArticoloDTO model)
        {
            try
            {
                var resp = await _http.PutAsJsonAsync("articoli/" + id, model);

                if (resp.IsSuccessStatusCode)
                {
                    var retItem = await resp.Content.ReadFromJsonAsync<ArticoloModel>();

                    if (retItem == null)
                    {
                        return null;
                    }

                    _msgService.SendMessage("Articolo modificato con successo", MessageType.Success, 5);
                    return retItem;
                }
                else
                {
                    await HandleError(resp);
                    return null;
                }
            }
            catch (Exception ex)
            {
                _msgService.SendMessage(ex.Message, MessageType.Error, 5);
                return null;
            }
        }

        public async Task<CategoriaModel?> EditCategoriaAsync(int id, CategoriaDTO model)
        {
            try
            {
                var resp = await _http.PutAsJsonAsync("categorie/" + id, model);

                if (resp.IsSuccessStatusCode)
                {
                    var retItem = await resp.Content.ReadFromJsonAsync<CategoriaModel>();

                    if (retItem == null)
                    {
                        return null;
                    }

                    _msgService.SendMessage("Categoria modificata con successo", MessageType.Success, 5);
                    return retItem;
                }
                else
                {
                    await HandleError(resp);
                    return null;
                }
            }
            catch (Exception ex)
            {
                _msgService.SendMessage(ex.Message, MessageType.Error, 5);
                return null;
            }
        }

        public async Task GetArticoliAsync()
        {
            try
            {
                // richiesta http
                var result = await _http.GetFromJsonAsync<List<ArticoloModel>>("articoli");

                if (result != null)
                {
                    Articoli = result;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public async Task GetArticoliByCategoriaIdAsync(int id)
        {
            try
            {
                var result = await _http.GetFromJsonAsync<List<ArticoloModel>>("categorie/" + id + "/articoli");

                if (result != null)
                {
                    Articoli = result;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public async Task GetArticoliMieiAsync()
        {
            try
            {
                // richiesta http
                var result = await _http.GetFromJsonAsync<List<ArticoloModel>>("articoli/miei");

                if (result != null)
                {
                    MieiArticoli = result;
                }

            }
            catch (Exception ex)
            {
                _msgService.SendMessage(ex.Message, MessageType.Error, 5);
            }
        }

        public async Task<ArticoloModel?> GetArticoloByIdAsync(int id)
        {
            try
            {
                return await _http.GetFromJsonAsync<ArticoloModel>("articoli/" + id);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<ArticoloDTO?> GetArticoloEditByIdAsync(int id)
        {
            return await _http.GetFromJsonAsync<ArticoloDTO?>("articoli/edit/" + id);
        }

        public async Task<CategoriaModel?> GetCategoriaByIdAsync(int id)
        {
            try
            {
                return await _http.GetFromJsonAsync<CategoriaModel?>("categorie/" + id);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<CategoriaDTO?> GetCategoriaEditByIdAsync(int id)
        {
            return await _http.GetFromJsonAsync<CategoriaDTO?>("categorie/edit/" + id);
        }

        public async Task GetCategorieAsync()
        {
            try
            {
                var result = await _http.GetFromJsonAsync<List<CategoriaModel>>("categorie");

                if (result != null)
                {
                    Categorie = result;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public async Task<UtenteInfo?> LoginAsync(LoginDTO model)
        {
            try
            {
                var resp = await _http.PostAsJsonAsync("utenti/login", model);

                if (resp.IsSuccessStatusCode)
                {
                    var user = await resp.Content.ReadFromJsonAsync<UtenteInfo>();

                    if (user == null)
                        return null;

                    await _localStorage.SetItemAsync("user", user);
                    await _authState.GetAuthenticationStateAsync();

                    _msgService.SendMessage("Benvenuto " + user.Utente?.Nome, MessageType.Success, 5);

                    return user;
                }
                else
                {
                    await HandleError(resp);
                    return null;
                }
            }
            catch (Exception ex)
            {
                _msgService.SendMessage(ex.Message, MessageType.Error, 5);
                return null;
            }
        }

        public async Task<UtenteInfo?> RegisterAsync(RegisterDTO model)
        {
            try
            {
                var resp = await _http.PostAsJsonAsync("utenti/register", model);

                if (resp.IsSuccessStatusCode)
                {
                    var user = await resp.Content.ReadFromJsonAsync<UtenteInfo>();

                    if (user == null)
                        return null;

                    _msgService.SendMessage("Registrazione avvenuta con successo", MessageType.Success, 5);

                    return user;
                }
                else
                {
                    await HandleError(resp);
                    return null;
                }
            }
            catch (Exception ex)
            {
                _msgService.SendMessage(ex.Message, MessageType.Error, 5);
                return null;
            }
        }

        private async Task HandleError(HttpResponseMessage res)
        {
            var strError = string.Empty;

            try
            {
                var error = await res.Content.ReadFromJsonAsync<ErrorModel>();
                strError = error.Detail;
            }
            catch
            {
                strError = await res.Content.ReadAsStringAsync();
            }

            _msgService.SendMessage($"{res.StatusCode}: {strError}", MessageType.Error, 10);
        }
    }
}

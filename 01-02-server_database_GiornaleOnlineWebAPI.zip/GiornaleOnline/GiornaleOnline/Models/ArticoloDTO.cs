﻿using System.ComponentModel.DataAnnotations;

namespace GiornaleOnline.Models
{    
    public class ArticoloDTO
    {
        public int Id { get; set; }       

        [Required]
        public int CategoriaId { get; set; }

        [Required]
        [MaxLength(150)]
        public string? Titolo { get; set; }

        [Required]
        public string? Testo { get; set; }

        public bool Pubblicato { get; set; } = false;
        
        public DateTime DataCreazione { get; set; }

        public DateTime DataUltimaModifica { get; set; }
    }
}

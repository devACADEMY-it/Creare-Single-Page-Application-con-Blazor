﻿namespace GiornaleOnline.BlazorWASM.Models
{
    public class ErrorModel
    {
        //"type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
        //"title": "One or more validation errors occurred.",
        //"status": 400,
        //"traceId": "00-09e58d77242073ec9e28e2452e80ad59-ed92f40c37908ea2-00",
        //"errors": {
        //    "Password": [
        //        "The Password field is required."
        //    ]
        //}
        public string? Type { get; set; }
        public string? TraceId { get; set; }
        public string? Title { get; set; }
        public int Status { get; set; }
        public string? Detail { get; set; }
    }
}

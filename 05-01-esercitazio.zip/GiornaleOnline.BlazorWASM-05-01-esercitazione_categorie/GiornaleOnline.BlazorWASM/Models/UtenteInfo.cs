﻿namespace GiornaleOnline.BlazorWASM.Models
{    
    public class UtenteInfo
    {
        public UtenteModel? Utente { get; set; }

        public string? Token { get; set; }
    }
}

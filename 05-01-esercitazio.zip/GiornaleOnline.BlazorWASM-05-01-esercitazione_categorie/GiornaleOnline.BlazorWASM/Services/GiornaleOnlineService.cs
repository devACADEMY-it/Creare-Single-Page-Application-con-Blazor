﻿using GiornaleOnline.BlazorWASM.Models;
using System.Net.Http.Json;

namespace GiornaleOnline.BlazorWASM.Services
{
    public interface IGiornaleOnlineService
    {
        List<ArticoloModel> Articoli { get; set; }
        Task GetArticoliAsync();
        Task<ArticoloModel?> GetArticoloByIdAsync(int id);
    }

    public class GiornaleOnlineService : IGiornaleOnlineService
    {
        private readonly HttpClient _http;
        public GiornaleOnlineService(HttpClient http)
        {
            _http = http;
        }

        public List<ArticoloModel> Articoli { get; set; }

        public async Task GetArticoliAsync()
        {
            try
            {
                // richiesta http
                var result = await _http.GetFromJsonAsync<List<ArticoloModel>>("articoli");

                if (result != null)
                {
                    Articoli = result;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public async Task<ArticoloModel?> GetArticoloByIdAsync(int id)
        {
            try
            {                
                return await _http.GetFromJsonAsync<ArticoloModel>("articoli/" + id);
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }
}

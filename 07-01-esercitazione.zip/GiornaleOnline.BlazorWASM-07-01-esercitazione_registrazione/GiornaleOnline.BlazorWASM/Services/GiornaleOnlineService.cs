﻿using Blazored.LocalStorage;
using GiornaleOnline.BlazorWASM.Models;
using Microsoft.AspNetCore.Components.Authorization;
using System.Net.Http.Json;

namespace GiornaleOnline.BlazorWASM.Services
{
    public interface IGiornaleOnlineService
    {
        List<ArticoloModel> Articoli { get; set; }
        List<CategoriaModel> Categorie { get; set; }
        Task GetArticoliAsync();
        Task<ArticoloModel?> GetArticoloByIdAsync(int id);
        Task GetCategorieAsync();
        Task<CategoriaModel?> GetCategoriaByIdAsync(int id);
        Task GetArticoliByCategoriaIdAsync(int id);

        // Autenticazione
        Task<UtenteInfo?> LoginAsync(LoginDTO model);

        // 07-ESERCITAZIONE REGISTRAZIONE
        // - Creare il metodo in IGiornaleOnlineService per la registrazione sul server API
        // - Creare la pagina con form di registrazione che utilizzi il metodo di cui sopra
    }

    public class GiornaleOnlineService : IGiornaleOnlineService
    {
        private readonly HttpClient _http;
        private readonly ILocalStorageService _localStorage;
        private readonly AuthenticationStateProvider _authState;

        public GiornaleOnlineService(HttpClient http, ILocalStorageService localStorage, AuthenticationStateProvider authState)
        {
            _http = http;
            _localStorage = localStorage;
            _authState = authState;
        }

        public List<ArticoloModel> Articoli { get; set; }
        public List<CategoriaModel> Categorie { get; set; }

        public async Task GetArticoliAsync()
        {
            try
            {
                // richiesta http
                var result = await _http.GetFromJsonAsync<List<ArticoloModel>>("articoli");

                if (result != null)
                {
                    Articoli = result;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public async Task GetArticoliByCategoriaIdAsync(int id)
        {
            try
            {                
                var result = await _http.GetFromJsonAsync<List<ArticoloModel>>("categorie/" + id + "/articoli");

                if (result != null)
                {
                    Articoli = result;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public async Task<ArticoloModel?> GetArticoloByIdAsync(int id)
        {
            try
            {                
                return await _http.GetFromJsonAsync<ArticoloModel>("articoli/" + id);
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task<CategoriaModel?> GetCategoriaByIdAsync(int id)
        {
            try
            {
                return await _http.GetFromJsonAsync<CategoriaModel?>("categorie/" + id);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public async Task GetCategorieAsync()
        {
            try
            {                
                var result = await _http.GetFromJsonAsync<List<CategoriaModel>>("categorie");

                if (result != null)
                {
                    Categorie = result;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public async Task<UtenteInfo?> LoginAsync(LoginDTO model)
        {
            try
            {
                var resp = await _http.PostAsJsonAsync("utenti/login", model);

                if (resp.IsSuccessStatusCode)
                {
                    var user = await resp.Content.ReadFromJsonAsync<UtenteInfo>();

                    if (user == null)
                        return null;

                    await _localStorage.SetItemAsync("user", user);
                    await _authState.GetAuthenticationStateAsync();

                    return user;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
